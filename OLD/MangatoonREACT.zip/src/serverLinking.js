// var config = require("config");

// var ip = config.get("ip")
// var port = config.get("port")


//const Link = `${ip}:${port}`

const serverLink = "http://localhost:4000"
export default serverLink;