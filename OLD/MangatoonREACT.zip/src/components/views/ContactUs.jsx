import React from "react";
import "./viewCSS/Other.css"
const ContactUs = () => {
  return (
    <div>
      <p className="about">Welcome to Mangatoon where a Huge Library of Literary Artworks is Just Waiting to be Explored By You!</p>
    </div>
  );
};

export default ContactUs;
